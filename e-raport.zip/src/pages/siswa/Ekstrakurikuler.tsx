import { AppLayout } from '@/components/layout/AppLayout';
import { PageHeader } from '@/components/common/PageHeader';
import { extracurriculars } from '@/data/mockData';
import { Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const SiswaEkstrakurikuler = () => {
  return (
    <AppLayout>
      <PageHeader
        title="Ekstrakurikuler"
        description="Daftar kegiatan ekstrakurikuler jenjang SMP yang diikuti dan tersedia"
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {extracurriculars.map((item) => (
          <div
            key={item.id}
            className="bg-card rounded-xl border border-border p-4 hover:border-primary/50 hover:shadow-elevated transition-all"
          >
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-foreground">{item.name}</h3>
                <p className="text-sm text-muted-foreground">Pelatih: {item.coach}</p>
              </div>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                <Users className="h-3 w-3 mr-1" />
                {item.members} siswa
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-2">Jadwal: {item.schedule}</p>
            <button className="btn-secondary text-xs">Lihat Detail</button>
          </div>
        ))}
      </div>
    </AppLayout>
  );
};

export default SiswaEkstrakurikuler;
