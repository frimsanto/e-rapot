import { AppLayout } from '@/components/layout/AppLayout';
import { PageHeader } from '@/components/common/PageHeader';
import { p5Projects } from '@/data/mockData';
import { Badge } from '@/components/ui/badge';
import { ClipboardList } from 'lucide-react';

const SiswaP5 = () => {
  return (
    <AppLayout>
      <PageHeader
        title="Projek P5"
        description="Portofolio projek Penguatan Profil Pelajar Pancasila untuk jenjang SMP"
      />
      <div className="space-y-3">
        {p5Projects.map((project) => (
          <div
            key={project.id}
            className="bg-card rounded-xl border border-border p-4 flex items-start justify-between"
          >
            <div>
              <div className="flex items-center gap-2 mb-1">
                <ClipboardList className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-foreground">{project.name}</h3>
              </div>
              <p className="text-sm text-muted-foreground">Tema: {project.theme}</p>
            </div>
            <div className="text-right space-y-2">
              <Badge variant="outline" className="text-xs">
                {project.status === 'completed' && 'Selesai'}
                {project.status === 'ongoing' && 'Berjalan'}
                {project.status === 'planned' && 'Direncanakan'}
              </Badge>
              {project.score !== null && (
                <p className="text-sm font-semibold text-foreground">Nilai: {project.score}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </AppLayout>
  );
};

export default SiswaP5;
