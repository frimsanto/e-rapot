import { AppLayout } from '@/components/layout/AppLayout';
import { PageHeader } from '@/components/common/PageHeader';
import { ukkData } from '@/data/mockData';
import { Badge } from '@/components/ui/badge';
import { Award, Calendar } from 'lucide-react';

const SiswaUKK = () => {
  return (
    <AppLayout>
      <PageHeader
        title="Uji Kompetensi Keahlian (UKK)"
        description="Jadwal dan status pelaksanaan UKK untuk jenjang SMK"
      />
      <div className="space-y-3">
        {ukkData.map((item) => (
          <div
            key={item.id}
            className="bg-card rounded-xl border border-border p-4 flex items-start justify-between"
          >
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Award className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-foreground">{item.name}</h3>
              </div>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <Calendar className="h-3 w-3" /> {item.date} • {item.duration}
              </p>
            </div>
            <div className="text-right space-y-2">
              <Badge variant="outline" className="text-xs">
                {item.status === 'scheduled' && 'Terjadwal'}
                {item.status === 'completed' && 'Selesai'}
              </Badge>
              {item.score !== null && (
                <p className="text-sm font-semibold text-foreground">Nilai: {item.score}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </AppLayout>
  );
};

export default SiswaUKK;
