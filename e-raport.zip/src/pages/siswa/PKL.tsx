import { AppLayout } from '@/components/layout/AppLayout';
import { PageHeader } from '@/components/common/PageHeader';
import { pklData } from '@/data/mockData';
import { Badge } from '@/components/ui/badge';
import { Briefcase } from 'lucide-react';

const SiswaPKL = () => {
  return (
    <AppLayout>
      <PageHeader
        title="PKL / Prakerin"
        description="Informasi penempatan dan progres Praktik Kerja Lapangan untuk jenjang SMK"
      />
      <div className="space-y-3">
        {pklData.map((item) => (
          <div
            key={item.id}
            className="bg-card rounded-xl border border-border p-4 flex items-start justify-between"
          >
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Briefcase className="h-4 w-4 text-primary" />
                <h3 className="font-semibold text-foreground">{item.company}</h3>
              </div>
              <p className="text-sm text-muted-foreground">Pembimbing: {item.supervisor}</p>
              <p className="text-xs text-muted-foreground">Periode: {item.startDate} - {item.endDate}</p>
            </div>
            <div className="text-right space-y-2">
              <Badge variant="outline" className="text-xs">
                {item.status === 'active' && 'Sedang berlangsung'}
                {item.status === 'completed' && 'Selesai'}
              </Badge>
              {item.score !== null && (
                <p className="text-sm font-semibold text-foreground">Nilai: {item.score}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </AppLayout>
  );
};

export default SiswaPKL;
