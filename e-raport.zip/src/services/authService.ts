import { AuthResponse, BackendRole, Jenjang } from '@/types/auth';

const defaultRouteByRole: Record<BackendRole, string> = {
  SISWA: '/siswa',
  GURU: '/guru',
  KURIKULUM: '/kurikulum',
  WALI_KELAS: '/walikelas',
  KEPALA_SEKOLAH: '/kepalasekolah',
  ADMIN: '/admin',
};

// Simple in-memory mock user directory
const mockUsers: { email: string; password: string; name: string; role: BackendRole; jenjang?: Jenjang }[] = [
  // Siswa per jenjang
  { email: 'siswa.sd@sekolah.sch.id', password: 'password', name: 'Ahmad SD', role: 'SISWA', jenjang: 'SD' },
  { email: 'siswa.smp@sekolah.sch.id', password: 'password', name: 'Budi SMP', role: 'SISWA', jenjang: 'SMP' },
  { email: 'siswa.sma@sekolah.sch.id', password: 'password', name: 'Citra SMA', role: 'SISWA', jenjang: 'SMA' },
  { email: 'siswa.smk@sekolah.sch.id', password: 'password', name: 'Dewi SMK', role: 'SISWA', jenjang: 'SMK' },

  // Guru per jenjang
  { email: 'guru.sd@sekolah.sch.id', password: 'password', name: 'Ibu Rina SD', role: 'GURU', jenjang: 'SD' },
  { email: 'guru.smp@sekolah.sch.id', password: 'password', name: 'Ibu Sri SMP', role: 'GURU', jenjang: 'SMP' },
  { email: 'guru.sma@sekolah.sch.id', password: 'password', name: 'Pak Andi SMA', role: 'GURU', jenjang: 'SMA' },
  { email: 'guru.smk@sekolah.sch.id', password: 'password', name: 'Pak Budi SMK', role: 'GURU', jenjang: 'SMK' },

  // Peran lain
  { email: 'kurikulum@sekolah.sch.id', password: 'password', name: 'Pak Bambang', role: 'KURIKULUM' },
  { email: 'walikelas@sekolah.sch.id', password: 'password', name: 'Ibu Dewi', role: 'WALI_KELAS', jenjang: 'SMP' },
  { email: 'kepala@sekolah.sch.id', password: 'password', name: 'Dr. Hadi', role: 'KEPALA_SEKOLAH' },
  { email: 'admin@sekolah.sch.id', password: 'password', name: 'Administrator', role: 'ADMIN' },
];

export async function login(email: string, password: string): Promise<AuthResponse> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 600));

  const normalizedEmail = email.trim().toLowerCase();
  const user = mockUsers.find((u) => u.email.toLowerCase() === normalizedEmail && u.password === password);

  if (!user) {
    throw new Error('Email atau password salah');
  }

  return {
    token: 'dummy-token',
    user: {
      id: normalizedEmail,
      name: user.name,
      email: normalizedEmail,
      role: user.role,
      jenjang: user.jenjang,
    },
  };
}

export { defaultRouteByRole };
